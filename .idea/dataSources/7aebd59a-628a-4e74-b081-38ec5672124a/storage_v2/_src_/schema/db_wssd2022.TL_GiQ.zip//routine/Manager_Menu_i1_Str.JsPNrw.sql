create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Menu_i1_Str(IN iSetIcon varchar(100),
                                                                          IN iDisplayYn varchar(1),
                                                                          IN iDisplayOrder int, IN iParentMenuSeq int,
                                                                          IN iMenuName varchar(100),
                                                                          IN iProgramUrl varchar(100),
                                                                          IN iProgramParameter varchar(100),
                                                                          IN iLoginUserSeq int)
begin
	 DECLARE menuExist int;
     DECLARE existCount int;
	 DECLARE exicon varchar(100);
	
	SET menuExist = (SELECT IFNULL(MAX(DISPLAY_ORDER)+1, 1) from manager_menu);

	IF (iParentMenuSeq != 0) THEN
		SET exicon = null;
	ELSE		
		SET exicon = iSetIcon;
	END	IF;

	
	INSERT INTO manager_menu
	(
		parent_menu_seq,
		menu_name,
		set_icon, 
		program_url,
		program_parameter,
		display_yn,
		display_order,
		regist_by,
		regist_date,
		update_by,
		update_date
	)
	values
	(
		IFNULL(iParentMenuSeq, 0),
		iMenuName,
		exicon,
		iProgramUrl,
		iProgramParameter,
		iDisplayYn,
		iDisplayOrder,
		iLoginUserSeq,
		now(),
		iLoginUserSeq,
		now()
	);
	
end;

