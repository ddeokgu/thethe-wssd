create
    definer = usr_wssd2022@`211.193.31.117` function ttcc_get_common_code_maker(CODE_GUBUN varchar(4), CODE_KEY int) returns varchar(20)
BEGIN
	
	DECLARE COMM_CODE VARCHAR(20);

	SET COMM_CODE = CONCAT( CODE_GUBUN , RIGHT(CONCAT('000000' , CAST(CODE_KEY AS CHAR)), 6));
	
	RETURN COMM_CODE;

END;

