create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Auth_Group_S1_Str(IN p_iAuthGroupSeq int,
                                                                                IN p_iAuthGroupName varchar(100),
                                                                                IN p_iUseYn char, IN p_iRowsPerPage int,
                                                                                IN p_iCurrentPage int)
BEGIN


    SELECT
        -- T.TOTAL_COUNT AS totalCount,
        T.ROW_INDEX  AS rowIndex,
        T.AUTH_GROUP_SEQ AS authGroupSeq,
        T.AUTH_GROUP_NAME AS authGroupName,
        T.USE_YN AS useYn,
        (SELECT M.MB_CD FROM MANAGER_LIST M WHERE M.MANAGER_SEQ = T.REGIST_BY) AS registBy,
        DATE_FORMAT (T.REGIST_DATE, '%Y-%m-%d') AS registDate,
        (SELECT M.MB_CD FROM MANAGER_LIST M WHERE M.MANAGER_SEQ = T.UPDATE_BY) AS updateBy,
        DATE_FORMAT (T.UPDATE_DATE, '%Y-%m-%d') AS updateDate
    FROM (
		select * from (
			SELECT
				-- COUNT(*) OVER() AS TOTAL_COUNT,
				@rownum:=@rownum+1 as ROW_INDEX,
				A.AUTH_GROUP_SEQ AS AUTH_GROUP_SEQ,
				A.AUTH_GROUP_NAME AS AUTH_GROUP_NAME,
				A.USE_YN AS USE_YN,
				A.REGIST_BY AS REGIST_BY,
				A.REGIST_DATE AS REGIST_DATE,
				A.UPDATE_BY AS UPDATE_BY,
				A.UPDATE_DATE AS UPDATE_DATE
			FROM MANAGER_AUTH_GROUP A,  (select @rownum := 0) as B
			WHERE
				(p_iAuthGroupSeq IS NULL OR p_iAuthGroupSeq > 0 OR A.AUTH_GROUP_SEQ = p_iAuthGroupSeq)
				AND (p_iUseYn IS NULL OR p_iUseYn = '' OR A.USE_YN = p_iUseYn)
				AND (p_iAuthGroupName IS NULL OR p_iAuthGroupName = '' OR A.AUTH_GROUP_NAME LIKE Concat('%' , p_iAuthGroupName , '%') COLLATE utf8_general_ci)
		) LIST where LIST.ROW_INDEX between ((p_iCurrentPage-1)*p_iRowsPerPage)+1 AND p_iRowsPerPage*(p_iCurrentPage) order by ROW_INDEX

    ) T
   order by T.AUTH_GROUP_SEQ desc;
END;

