create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Auth_Group_U1_Str(IN iManagerSeq int,
                                                                                IN iAuthGroupSeq int,
                                                                                IN iAuthGroupName varchar(100),
                                                                                IN iUseYn char)
begin
	
		UPDATE MANAGER_AUTH_GROUP SET
			AUTH_GROUP_NAME = iAuthGroupName,
			USE_YN = iUseYn,
			UPDATE_BY = iManagerSeq,
			UPDATE_DATE = now()
		WHERE
			AUTH_GROUP_SEQ = iAuthGroupSeq;
	

	
		DELETE FROM MANAGER_MENU_GROUP
		WHERE AUTH_GROUP_SEQ = iAuthGroupSeq;
END;

