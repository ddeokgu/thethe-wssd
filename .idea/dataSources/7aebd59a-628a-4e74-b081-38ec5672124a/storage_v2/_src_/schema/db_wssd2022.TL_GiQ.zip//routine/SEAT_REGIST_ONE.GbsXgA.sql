create
    definer = usr_wssd2022@`211.193.31.117` procedure SEAT_REGIST_ONE(IN $SEAT_NAME varchar(100),
                                                                      IN $ROOM_CODE varchar(100),
                                                                      IN $REG_ID varchar(100))
BEGIN

DECLARE count INT;

SET count = (select count(*) from tb_seat 
where ROOM_CODE=$ROOM_CODE 
and SEAT_NAME = $SEAT_NAME);

	if count > 0 then
		update tb_seat set DLT_YN = 'N' where ROOM_CODE = $ROOM_CODE and SEAT_NAME = $SEAT_NAME;
	else
		insert into tb_seat (SEAT_NAME, ROOM_CODE, REG_ID, REG_DATE)
			values ($SEAT_NAME, $ROOM_CODE, $REG_ID, NOW());
	end if;
	
	update tb_room set SEAT_COUNT = SEAT_COUNT + 1 where ROOM_CODE = $ROOM_CODE; 
	
end;

