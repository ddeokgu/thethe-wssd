create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Menu_S2_Str(IN iManagerSeq int, IN iManagerId varchar(50),
                                                                          IN iAuthGroupSeq int,
                                                                          IN iManagerName varchar(50), IN iUseYn char)
begin
  DROP TEMPORARY TABLE IF EXISTS tree_menu;
  DROP TEMPORARY TABLE IF EXISTS tree_menu2;
  DROP TEMPORARY TABLE IF EXISTS tree_menu3;
 
 
  CREATE TEMPORARY TABLE tree_menu (
       SELECT
    		A.MENU_SEQ as MENU_SEQ,
    		A.PARENT_MENU_SEQ as PARENT_MENU_SEQ,
    		A.MENU_NAME as MENU_NAME,
    		A.PROGRAM_URL as PROGRAM_URL,
    		A.DISPLAY_ORDER as SORT,
    		CONVERT(RIGHT(CONCAT('0000' , CONVERT(A.DISPLAY_ORDER, CHAR(4))), 4), char(255)) as DEP_SORT,
    		CONVERT(A.MENU_NAME, char(255)) as DEP_NAME,
    		1 as DEPTH
    	FROM
    		MANAGER_MENU A
    	WHERE
    		A.PARENT_MENU_SEQ = 0
    		AND A.DISPLAY_YN = 'Y'
    );
   
   
    CREATE TEMPORARY TABLE tree_menu2 (	
    SELECT
    		B.MENU_SEQ as MENU_SEQ,
    		B.PARENT_MENU_SEQ as PARENT_MENU_SEQ,
    		B.MENU_NAME as MENU_NAME,
    		B.PROGRAM_URL as PROGRAM_URL,
    		B.DISPLAY_ORDER as SORT,
    		CONVERT(concat(C.DEP_SORT, ' > ', RIGHT(concat('0000', CONVERT(B.DISPLAY_ORDER,CHAR(4))), 4)), char(255)) as DEP_SORT,
    		CONVERT(concat(C.DEP_NAME , ' > ' , B.MENU_NAME), char(255)) as DEP_NAME,
    		(C.DEPTH + 1) as DEPTH
    	FROM
    		MANAGER_MENU B INNER JOIN tree_menu C ON B.PARENT_MENU_SEQ = C.MENU_SEQ
    	WHERE
    		B.DISPLAY_YN = 'Y'
	);
		
	CREATE TEMPORARY TABLE  tree_menu3 (
     SELECT
    		B.MENU_SEQ as MENU_SEQ,
    		B.PARENT_MENU_SEQ as PARENT_MENU_SEQ,
    		B.MENU_NAME as MENU_NAME,
    		B.PROGRAM_URL as PROGRAM_URL,
    		B.DISPLAY_ORDER as SORT,
    		CONVERT(concat(C.DEP_SORT, ' > ', RIGHT(concat('0000', CONVERT(B.DISPLAY_ORDER,CHAR(4))), 4)), char(255)) as DEP_SORT,
    		CONVERT(concat(C.DEP_NAME , ' > ' , B.MENU_NAME), char(255)) as DEP_NAME,
    		(C.DEPTH + 1) as DEPTH
    	FROM
    		MANAGER_MENU B INNER JOIN tree_menu2 C ON B.PARENT_MENU_SEQ = C.MENU_SEQ
    	WHERE
    		B.DISPLAY_YN = 'Y'
	);
	
	
	 SELECT
        @ROWNUM := @ROWNUM+1 AS rowIndex,
        C.MENU_SEQ AS menuSeq,
        C.PARENT_MENU_SEQ AS parentMenuSeq,
        C.MENU_NAME AS menuName,
        C.PROGRAM_URL AS programUrl,
    	C.DEPTH AS menuLevel,
		C.SORT AS displayOrder
    FROM  
    (   select * from tree_menu
		union all
		select * from tree_menu2
		union all
		select * from tree_menu3
	) as C , (select @ROWNUM:=0) T
    ORDER BY C.DEP_SORT;
	
	
	
	
	
END;

