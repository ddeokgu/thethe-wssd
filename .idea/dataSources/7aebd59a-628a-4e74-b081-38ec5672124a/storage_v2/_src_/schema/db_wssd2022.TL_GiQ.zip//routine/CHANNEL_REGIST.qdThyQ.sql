create
    definer = usr_wssd2022@`211.193.31.117` procedure CHANNEL_REGIST(IN $CODE_TYPE varchar(50),
                                                                     IN $CHANNEL_NAME varchar(100),
                                                                     IN $CHANNEL_ZIP varchar(50),
                                                                     IN $CHANNEL_ADDRESS varchar(100),
                                                                     IN $CHANNEL_ADDRESS_DETAIL varchar(100),
                                                                     IN $USE_YN char, IN $REG_ID varchar(50))
begin
	
	declare CHANNEL_CODE varchar(50);
	declare CHANNEL_SEQ varchar(50);
	
	
	set CHANNEL_SEQ = ifnull((select max(tc.CHANNEL_SEQ)
	from tb_channel tc), 0) + 1;
	set CHANNEL_CODE = concat($CODE_TYPE,CHANNEL_SEQ);
	
	insert into tb_channel (CHANNEL_CODE, CHANNEL_NAME,CHANNEL_ZIP, CHANNEL_ADDRESS, CHANNEL_ADDRESS_DETAIL, USE_YN, REG_ID, REG_DATE) 
	values (channel_code, $CHANNEL_NAME, $CHANNEL_ZIP, $CHANNEL_ADDRESS, $CHANNEL_ADDRESS_DETAIL, $USE_YN, $REG_ID, NOW());
	
end;

