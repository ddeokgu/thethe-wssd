create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Auth_Group_S2_Str(IN iAuthGroupSeq int)
begin
	
	 select
	a.auth_group_seq as authGroupSeq,
	a.auth_group_name as authGroupName,
	a.use_yn as useYn,
	b.menu_seq as menuSeq
from manager_auth_group a
inner join manager_menu_group b on b.auth_group_seq = a.auth_group_seq
where a.auth_group_seq = iAuthGroupSeq;
END;

