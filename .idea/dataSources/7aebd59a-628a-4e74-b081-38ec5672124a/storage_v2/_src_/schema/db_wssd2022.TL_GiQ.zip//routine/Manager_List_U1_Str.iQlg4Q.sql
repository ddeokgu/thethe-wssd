create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_List_U1_Str(IN p_iManagerSeq int,
                                                                          IN p_iManagerId varchar(10),
                                                                          IN p_iChangePasswordYn char,
                                                                          IN p_iPassword varchar(200),
                                                                          IN p_iAuthGroupSeq int,
                                                                          IN p_iManagerName varchar(50),
                                                                          IN p_iManagerEmail varchar(50),
                                                                          IN p_iUseYn char,
                                                                          IN p_iDescription varchar(200),
                                                                          IN p_iUpdateBy varchar(50),
                                                                          IN p_mb_cd varchar(30))
begin
	
	
	DECLARE onepassword varchar(200)  ;
	DECLARE onepassword2 varchar(200)  ;
	DECLARE loginfailcnt int(11) ;
     set onepassword = (SELECT A.PASSWORD FROM manager_list A WHERE A.MANAGER_SEQ = p_iManagerSeq); 
     set onepassword2 = (select MU_PW  FROM tb_member_user WHERE MU_ID = p_iManagerId); 
     set loginfailcnt = (SELECT A.LOGIN_FAIL_COUNT FROM manager_list A WHERE A.MANAGER_SEQ = p_iManagerSeq); 
	

    UPDATE manager_list b set 
        b.PASSWORD =  
        (CASE 
        WHEN p_iChangePasswordYn = 'Y' THEN p_iPassword 
        ELSE onepassword 
        end ),
        b.LOGIN_FAIL_COUNT = 
        (CASE 
        WHEN p_iUseYn = 'Y' THEN 0 
        ELSE loginfailcnt
        end),
        b.AUTH_GROUP_SEQ = p_iAuthGroupSeq,
        b.MANAGER_NAME = p_iManagerName,
        b.MANAGER_EMAIL = p_iManagerEmail,
        b.USE_YN = p_iUseYn,
        b.DESCRIPTION = p_iDescription,
        b.UPDATE_BY = p_iUpdateBy,
        b.UPDATE_DATE = NOW()
    WHERE
    b.MANAGER_SEQ = p_iManagerSeq;
 
    UPDATE tb_member_user SET
    MU_PW = (CASE 
        WHEN p_iChangePasswordYn = 'Y' THEN p_iPassword 
        ELSE onepassword 
        end ),
    MU_IS_LIVE = p_iUseYn
    WHERE MU_CD = p_mb_cd;
    
END;

