create
    definer = usr_wssd2022@`211.193.31.117` procedure SCHOOL_REGIST(IN $CODE_TYPE varchar(50),
                                                                    IN $SCHOOL_NAME varchar(100),
                                                                    IN $SCHOOL_ZIP varchar(50),
                                                                    IN $SCHOOL_ADDRESS varchar(100),
                                                                    IN $SCHOOL_ADDRESS_DETAIL varchar(100),
                                                                    IN $SCHOOL_PHONE varchar(50), IN $USE_YN char,
                                                                    IN $REG_ID varchar(50))
begin
	
	declare SCHOOL_CODE varchar(50);
	declare SCHOOL_SEQ varchar(50);
	
	
	set SCHOOL_SEQ = ifnull((select max(ts.SCHOOL_SEQ)
	from TB_SCHOOL ts), 0) + 1;
	set SCHOOL_CODE = concat($CODE_TYPE,SCHOOL_SEQ);
	
	insert into tb_school (SCHOOL_CODE, SCHOOL_NAME, SCHOOL_ZIP, SCHOOL_ADDRESS, SCHOOL_ADDRESS_DETAIL, SCHOOL_PHONE, USE_YN, REG_ID, REG_DATE) 
	values (SCHOOL_CODE, $SCHOOL_NAME, $SCHOOL_ZIP,$SCHOOL_ADDRESS,$SCHOOL_ADDRESS_DETAIL, $SCHOOL_PHONE, $USE_YN, $REG_ID, NOW());
	
end;

