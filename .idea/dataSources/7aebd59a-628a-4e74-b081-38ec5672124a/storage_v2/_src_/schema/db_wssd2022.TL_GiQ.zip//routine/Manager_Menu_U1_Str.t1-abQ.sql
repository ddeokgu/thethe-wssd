create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Menu_U1_Str(IN iSetIcon varchar(100),
                                                                          IN iDisplayYn varchar(1),
                                                                          IN iDisplayOrder varchar(100),
                                                                          IN iParentMenuSeq varchar(100),
                                                                          IN iMenuSeq varchar(100),
                                                                          IN iMenuName varchar(100),
                                                                          IN iProgramUrl varchar(100),
                                                                          IN iProgramParameter varchar(100),
                                                                          IN iUserSeq varchar(8))
begin
	DECLARE exicon varchar(100);
	
	
	IF (iParentMenuSeq != 0) THEN
		SET exicon = null;
	ELSE		
		SET exicon = iSetIcon;
	END	IF;
	
	
	
	UPDATE MANAGER_MENU SET
		DISPLAY_ORDER = iDisplayOrder,
		UPDATE_BY = iUserSeq,
		UPDATE_DATE = now()
	WHERE parent_menu_seq = iMenuSeq;


	UPDATE MANAGER_MENU SET
		parent_menu_seq = IFNULL(iParentMenuSeq, 0),
		set_icon = exicon,  
        menu_name = iMenuName,
		program_url = iProgramUrl,
		program_parameter = iProgramParameter,
		display_yn = iDisplayYn,
		display_order = iDisplayOrder,
		update_by = iUserSeq,
		update_date = now()
    WHERE
    menu_seq = iMenuSeq;
	
END;

