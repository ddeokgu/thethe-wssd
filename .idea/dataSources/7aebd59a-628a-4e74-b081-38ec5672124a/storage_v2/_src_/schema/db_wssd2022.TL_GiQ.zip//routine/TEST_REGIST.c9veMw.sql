create
    definer = usr_wssd2022@`211.193.31.117` procedure TEST_REGIST(IN $CODE_TYPE varchar(100),
                                                                  IN $TEST_NAME varchar(100), IN $USE_YN char,
                                                                  IN $REG_ID varchar(50))
begin
	
	declare TEST_CODE varchar(50);
	declare TEST_SEQ varchar(50);
	
	
	set TEST_SEQ = ifnull((select max(tt.TEST_SEQ)
	from tb_test tt), 0) + 1;
	set TEST_CODE = concat($CODE_TYPE,TEST_SEQ);
	
	insert into tb_test (TEST_CODE, TEST_NAME, USE_YN, REG_ID, REG_DATE) 
	values (TEST_CODE, $TEST_NAME, $USE_YN, $REG_ID, NOW());
	
end;

