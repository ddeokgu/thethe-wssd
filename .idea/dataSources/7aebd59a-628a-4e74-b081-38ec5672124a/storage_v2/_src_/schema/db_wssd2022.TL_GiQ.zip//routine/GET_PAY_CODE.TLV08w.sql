create
    definer = usr_wssd2022@`211.193.31.117` procedure GET_PAY_CODE()
BEGIN

DECLARE v_pay_key INT;
DECLARE v_pay_ct INT;
DECLARE v_pay_code VARCHAR(100);
	   
SET v_pay_ct = (select ifnull(max(PAY_SEQ), 0) from TB_PAY);
SET v_pay_key = v_pay_ct + 1;
SET v_pay_code = (SELECT db_wssd2022.ttcc_get_common_code_maker('PAY', v_pay_key));

   select v_pay_code;
END;

