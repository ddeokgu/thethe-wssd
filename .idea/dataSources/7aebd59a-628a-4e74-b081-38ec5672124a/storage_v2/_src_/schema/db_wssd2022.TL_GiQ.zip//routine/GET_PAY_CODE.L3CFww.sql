create
    definer = usr_wssd2022@`211.193.31.117` procedure GET_PAY_CODE(IN $MU_ID varchar(100))
BEGIN

DECLARE v_pay_key INT;
DECLARE v_pay_ct INT;
DECLARE v_pay_code VARCHAR(100);
declare v_date VARCHAR(50);
	   
set V_DATE =  replace (date_format(NOW(), '%Y-%m-%d'), '-','');
SET v_pay_ct = (select ifnull(max(PAY_SEQ), 0) from TB_PAY);
SET v_pay_key = v_pay_ct + 1;
SET v_pay_code = (SELECT db_wssd2022.ttcc_get_order_code_maker($MU_ID, v_pay_key, v_date));

   select v_pay_code;
END;

