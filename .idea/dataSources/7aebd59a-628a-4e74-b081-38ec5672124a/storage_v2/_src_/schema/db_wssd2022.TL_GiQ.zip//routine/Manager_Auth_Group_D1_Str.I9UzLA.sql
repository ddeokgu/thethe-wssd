create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Auth_Group_D1_Str(IN iAuthGroupSeq int)
begin
	
		DELETE FROM MANAGER_AUTH_GROUP
		WHERE AUTH_GROUP_SEQ = iAuthGroupSeq;

		DELETE FROM MANAGER_MENU_GROUP 
		WHERE AUTH_GROUP_SEQ = iAuthGroupSeq;
	
	
END;

