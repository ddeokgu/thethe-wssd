create
    definer = usr_wssd2022@`211.193.31.117` function ttcc_get_order_code_maker(CODE_GUBUN varchar(100), CODE_KEY int, CODE_DATE varchar(20)) returns varchar(50)
BEGIN
	
	DECLARE COMM_CODE VARCHAR(50);

	SET COMM_CODE = CONCAT( CODE_GUBUN ,CODE_DATE,'0000',CODE_KEY);
	
	RETURN COMM_CODE;

end;

