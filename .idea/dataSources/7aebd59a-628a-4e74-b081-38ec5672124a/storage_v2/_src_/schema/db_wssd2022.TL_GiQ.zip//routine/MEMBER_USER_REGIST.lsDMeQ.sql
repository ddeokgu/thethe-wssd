create
    definer = usr_wssd2022@`211.193.31.117` procedure MEMBER_USER_REGIST(IN $MU_ID varchar(100), IN $MU_PW varchar(200),
                                                                         IN $MU_NAME varchar(100), IN $MU_GENDER char,
                                                                         IN $MU_BIRTH varchar(50),
                                                                         IN $MU_ZIP varchar(50),
                                                                         IN $MU_ADDRESS varchar(200),
                                                                         IN $MU_PHONE varchar(100),
                                                                         IN $MU_EMAIL varchar(200), IN $MU_FUNNEL char,
                                                                         IN $MU_FUNNEL_DES varchar(100),
                                                                         IN $MB_TYPE char)
BEGIN

DECLARE v_mb_key INT;
DECLARE v_mb_ct INT;
DECLARE v_mb_code VARCHAR(10);
	   
SET v_mb_ct = (select ifnull(max(MU_SEQ), 0) from tb_member_user);
SET v_mb_key = v_mb_ct + 1;
SET v_mb_code = (SELECT db_wssd2022.ttcc_get_common_code_maker('PUSR', v_mb_key));

	  INSERT INTO tb_member_user(
		MU_SEQ,
        MU_ID,
        MU_PW,
        MU_NAME, 
        MU_GENDER,
        MU_BIRTH,
        MU_ZIP,
        MU_ADDRESS,
        MU_PHONE,
        MU_EMAIL,
        MU_FUNNEL,
        MU_FUNNEL_DES, 
        MU_CD,
        MB_TYPE,
        MU_LOGIN_CNT,
        MU_IS_PERMIT,
        MU_DATE_PERMIT,
        MU_UPD_DATE,
        REG_DATE
    ) VALUES (
		v_mb_key,
        $MU_ID,
        $MU_PW,
        $MU_NAME, 
        $MU_GENDER,
        $MU_BIRTH,
        $MU_ZIP,
        $MU_ADDRESS,
        $MU_PHONE,
        $MU_EMAIL,
        $MU_FUNNEL,
        $MU_FUNNEL_DES, 
        v_mb_code,
        $MB_TYPE,
        0,
        'Y',
        NOW(),
        NOW(),
        NOW()
    );
END;

