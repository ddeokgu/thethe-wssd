create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_List_D1_Str(IN p_iManagerSeq int, IN p_iDeleteBy int, IN p_mb_cd varchar(30))
begin
	
	
	UPDATE MANAGER_LIST set
	    delete_yn = 'Y',
        DELETE_BY = p_iDeleteBy,
        DELETE_DATE = NOW()
    WHERE
    MANAGER_SEQ = p_iManagerSeq;
	
	
END;

