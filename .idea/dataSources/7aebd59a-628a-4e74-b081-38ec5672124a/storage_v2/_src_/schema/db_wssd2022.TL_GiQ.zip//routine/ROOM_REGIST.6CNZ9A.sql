create
    definer = usr_wssd2022@`211.193.31.117` procedure ROOM_REGIST(IN $CODE_TYPE varchar(50), IN $ROOM_NAME varchar(100),
                                                                  IN $CHANNEL_CODE varchar(50), IN $USE_YN char,
                                                                  IN $SEAT_COUNT varchar(50), IN $REG_ID varchar(50))
begin
	
	declare ROOM_CODE varchar(50);
	declare ROOM_SEQ varchar(50);
	
	
	set ROOM_SEQ = ifnull((select max(tr.ROOM_SEQ)
	from TB_ROOM tr), 0) + 1;
	set ROOM_CODE = concat($CODE_TYPE,ROOM_SEQ);
	
	insert into TB_ROOM (ROOM_CODE, ROOM_NAME, CHANNEL_CODE, USE_YN, REG_ID, REG_DATE, SEAT_COUNT) 
	values (ROOM_CODE, $ROOM_NAME, $CHANNEL_CODE, $USE_YN, $REG_ID, NOW(), $SEAT_COUNT);

	select tr.ROOM_CODE from tb_room tr where tr.ROOM_SEQ = ROOM_SEQ ;
	
end;

