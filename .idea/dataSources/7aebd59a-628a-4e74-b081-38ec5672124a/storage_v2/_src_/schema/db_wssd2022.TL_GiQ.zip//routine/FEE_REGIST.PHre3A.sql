create
    definer = usr_wssd2022@`211.193.31.117` procedure FEE_REGIST(IN $CODE_TYPE varchar(50), IN $FEE_NAME varchar(100),
                                                                 IN $FEE_SET varchar(100), IN $MANAGER_SET char,
                                                                 IN $FEE_EXC_SET char, IN $FEE_EXC varchar(50),
                                                                 IN $CHANNEL_CODE varchar(100), IN $USE_YN char,
                                                                 IN $REG_ID varchar(50))
begin
	
	declare FEE_CODE varchar(50);
	declare FEE_SEQ varchar(50);
	
	
	set FEE_SEQ = ifnull((select max(tf.FEE_SEQ)
	from tb_FEE tf), 0) + 1;
	set FEE_CODE = concat($CODE_TYPE,FEE_SEQ);
	
	insert into tb_fee (FEE_CODE, FEE_NAME, FEE_SET, MANAGER_SET, FEE_EXC_SET, FEE_EXC, CHANNEL_CODE, USE_YN, REG_ID, REG_DATE) 
	values (FEE_CODE, $FEE_NAME, $FEE_SET, $MANAGER_SET, $FEE_EXC_SET, $FEE_EXC, $CHANNEL_CODE, $USE_YN, $REG_ID, NOW());
	
end;

