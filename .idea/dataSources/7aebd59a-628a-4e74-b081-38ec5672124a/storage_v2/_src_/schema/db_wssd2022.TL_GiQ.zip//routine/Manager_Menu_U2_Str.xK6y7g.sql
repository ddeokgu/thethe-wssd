create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Menu_U2_Str(IN iDisplayOrder int, IN iMenuSeq int, IN iLoginUserSeq int)
begin
	
	
	/*UPDATE MANAGER_MENU SET
		DISPLAY_ORDER = iDisplayOrder,
		UPDATE_BY = iLoginUserSeq,
		UPDATE_DATE = now() 
	WHERE PARENT_MENU_SEQ = iMenuSeq;*/

	UPDATE MANAGER_MENU SET
		DISPLAY_ORDER = iDisplayOrder,
		UPDATE_BY = iLoginUserSeq,
		UPDATE_DATE = now() 
    WHERE
    MENU_SEQ = iMenuSeq; 
END;

