create
    definer = usr_wssd2022@`211.193.31.117` procedure updatePassword(IN p_loginUserSeq int, IN p_password varchar(200),
                                                                     IN p_mbCd varchar(200))
begin
	
	update manager_list set
	password = p_password,
	update_by = p_loginUserSeq,
	update_date = now()
	where MB_CD = p_mbCd;


	update tb_member_user set
	MU_PW = p_password,
	MU_UPD_CD = p_loginUserSeq,
	MU_UPD_DATE = now()
	where MU_CD = p_mbCd;
	
	
	
	
END;

