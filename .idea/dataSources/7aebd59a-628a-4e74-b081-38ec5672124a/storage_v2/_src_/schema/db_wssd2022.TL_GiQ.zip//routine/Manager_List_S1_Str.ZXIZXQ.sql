create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_List_S1_Str(IN p_iAuthGroupSeq int,
                                                                          IN p_iStartDate varchar(10),
                                                                          IN p_iEndDate varchar(10),
                                                                          IN p_iSearchKeyword varchar(50),
                                                                          IN p_iSearchText varchar(200),
                                                                          IN p_iUseYn char, IN p_iRowsPerPage int,
                                                                          IN p_iCurrentPage int)
BEGIN
 	DECLARE v_iStartDate DATETIME;
	DECLARE v_iEndDate DATETIME;
	DECLARE tcnt int;
     set v_iStartDate = (select CONVERT(p_iStartDate, DATETIME)); 
     set v_iEndDate = (select CONVERT(p_iEndDate, DATETIME)); 
     set tcnt = (select count(*) from manager_list); 
    
 	
 SELECT
        T.ROW_INDEX  AS rowIndex,
        T.MANAGER_SEQ AS managerSeq,
        T.MANAGER_ID AS managerId,
        T.LOGIN_FAIL_COUNT AS loginFailCount,
        T.AUTH_GROUP_SEQ AS authGroupSeq,
        (SELECT M.AUTH_GROUP_NAME FROM MANAGER_AUTH_GROUP M WHERE M.auth_group_seq = T.AUTH_GROUP_SEQ) AS authGroupName,
        T.MANAGER_NAME AS managerName,
        T.MANAGER_EMAIL AS managerEmail,
        T.USE_YN AS useYn,
        T.useyn_txt AS useyn_txt,
        T.DESCRIPTION AS description,
        (SELECT M.MANAGER_NAME FROM MANAGER_LIST M WHERE M.MANAGER_SEQ = T.REGIST_BY) AS registBy,
        DATE_FORMAT (T.REGIST_DATE, '%Y-%m-%d') AS registDate,
        (SELECT M.MANAGER_NAME FROM MANAGER_LIST M WHERE M.MANAGER_SEQ = T.UPDATE_BY) AS updateBy,
        DATE_FORMAT (T.UPDATE_DATE, '%Y-%m-%d') AS updateDate,
		date_format (T.login_date, '%Y.%m.%d. %r') as loginDate,
		T.mb_cd as mbCd
    FROM (
		select  * from (
			SELECT 
				@rownum:=@rownum+1 as ROW_INDEX,
				ANY_VALUE(A.MANAGER_SEQ) AS MANAGER_SEQ,
				ANY_VALUE(A.MANAGER_ID) AS MANAGER_ID,
				ANY_VALUE(A.LOGIN_FAIL_COUNT) AS LOGIN_FAIL_COUNT,
				ANY_VALUE(A.AUTH_GROUP_SEQ) AS AUTH_GROUP_SEQ,
				ANY_VALUE(A.MANAGER_NAME) AS MANAGER_NAME,
				ANY_VALUE(A.MANAGER_EMAIL) AS MANAGER_EMAIL,
				ANY_VALUE(A.USE_YN) AS USE_YN,
				CASE ANY_VALUE(A.use_yn) 
				WHEN 0 THEN '사용안함'
				WHEN 1 THEN '사용'
				ELSE '' END AS useyn_txt,
				ANY_VALUE(A.DESCRIPTION) AS DESCRIPTION,
				ANY_VALUE(A.REGIST_BY) AS REGIST_BY,
				ANY_VALUE(A.REGIST_DATE) AS REGIST_DATE,
				ANY_VALUE(A.UPDATE_BY) AS UPDATE_BY,
				ANY_VALUE(A.UPDATE_DATE) AS UPDATE_DATE,
				ANY_VALUE(A.login_date) as login_date,
				ANY_VALUE((SELECT MU_CD FROM tb_member_user MUM WHERE MU_ID = A.manager_id AND MB_TYPE = 'M')) AS mb_cd
			FROM MANAGER_LIST A, (select @rownum := 0) as B
			where
			A.delete_yn = 'N'
			and (p_iAuthGroupSeq IS NULL OR p_iAuthGroupSeq = '' or A.AUTH_GROUP_SEQ = p_iAuthGroupSeq)
			and
			(p_iSearchKeyword > '' AND (
				 (p_iSearchKeyword = 'managerId' AND A.MANAGER_ID LIKE Concat('%' , p_iSearchText , '%') COLLATE utf8_general_ci)
			     OR (p_iSearchKeyword = 'managerName' AND A.MANAGER_NAME LIKE Concat('%' , p_iSearchText , '%') COLLATE utf8_general_ci)
				 OR (p_iSearchKeyword = 'managerEmail' AND A.MANAGER_EMAIL LIKE Concat('%' , p_iSearchText , '%') COLLATE utf8_general_ci)
				 OR (p_iSearchKeyword = 'registName' AND EXISTS(SELECT 1 FROM MANAGER_LIST T WHERE A.MANAGER_SEQ = T.MANAGER_SEQ AND T.MANAGER_NAME LIKE Concat('%' , p_iSearchText , '%') COLLATE utf8_general_ci))
				 OR (p_iSearchKeyword = 'all' AND Concat(A.MANAGER_ID , A.MANAGER_NAME , A.MANAGER_EMAIL , (SELECT T.MANAGER_NAME FROM MANAGER_LIST T WHERE A.MANAGER_SEQ = T.MANAGER_SEQ)) LIKE Concat('%' , p_iSearchText , '%') COLLATE utf8_general_ci)
				 )) 
		    and (p_iUseYn IS NULL OR p_iUseYn = '' or A.use_yn = p_iUseYn)
			ORDER BY A.REGIST_DATE DESC	
		) LIST where LIST.ROW_INDEX between ((p_iCurrentPage-1)*p_iRowsPerPage)+1 AND p_iRowsPerPage*(p_iCurrentPage) order by LIST.ROW_INDEX
		
		
	) T;

	
END;

