create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Auth_Group_i1_Str(IN iManagerSeq int, IN iUseYn char, IN iAuthGroupName varchar(100))
begin
	
		INSERT INTO MANAGER_AUTH_GROUP
		(
			AUTH_GROUP_NAME,
			USE_YN,
			REGIST_BY,
			REGIST_DATE,
			update_by,
			update_date 

		)
		VALUES
		(
			iAuthGroupName,
			iuseYn,
			iManagerSeq,
			now(),
			iManagerSeq,
			now()
		);
	SELECT LAST_INSERT_ID();
END;

