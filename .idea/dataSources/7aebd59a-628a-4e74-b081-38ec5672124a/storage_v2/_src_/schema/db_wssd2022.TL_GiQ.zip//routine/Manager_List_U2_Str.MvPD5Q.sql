create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_List_U2_Str(IN p_iManagerSeq int, IN p_iUseYn char, IN p_iUpdateBy varchar(50))
begin
	
	UPDATE manager_list b set 
        b.USE_YN = p_iUseYn,
        b.UPDATE_BY = p_iUpdateBy,
        b.UPDATE_DATE = NOW()
    WHERE
    b.MANAGER_SEQ = p_iManagerSeq; 
	
	
	
END;

