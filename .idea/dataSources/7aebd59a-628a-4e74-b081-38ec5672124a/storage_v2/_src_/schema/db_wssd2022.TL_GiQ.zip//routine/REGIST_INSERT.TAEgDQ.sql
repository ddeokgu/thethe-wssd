create
    definer = usr_wssd2022@`211.193.31.117` procedure REGIST_INSERT(IN $REGIST_MU_NAME varchar(100),
                                                                    IN $REGIST_MU_CD varchar(100),
                                                                    IN $REGIST_MU_ID varchar(100),
                                                                    IN $REGIST_MU_GENDER char,
                                                                    IN $REGIST_MU_PHONE varchar(100),
                                                                    IN $REGIST_FEE_TYPE varchar(100),
                                                                    IN $REGIST_MU_SCHOOL varchar(100),
                                                                    IN $REGIST_MU_GRADE char,
                                                                    IN $REGIST_EXAM varchar(100),
                                                                    IN $REGIST_EXAM_DES varchar(100),
                                                                    IN $REGIST_PHONE_TYPE varchar(50),
                                                                    IN $REGIST_PARENT_PHONE varchar(100),
                                                                    IN $REGIST_TEST_FIRST varchar(100),
                                                                    IN $REGIST_TEST_SECOND varchar(100),
                                                                    IN $REGIST_START_DATE datetime,
                                                                    IN $REGIST_END_DATE datetime,
                                                                    IN $REGIST_CHANNEL varchar(100),
                                                                    IN $REGIST_ROOM varchar(50),
                                                                    IN $REGIST_SEAT int(10), IN $REGIST_MU_TYPE char,
                                                                    IN $REGIST_TYPE char, IN $REG_ID varchar(100),
                                                                    IN $PAY_CODE varchar(100))
begin
	declare REGIST_FIRST_DATE datetime;
	
	set REGIST_FIRST_DATE = NOW();
	
	 insert into TB_REGIST (
	 						REGIST_FIRST_DATE,
                               REGIST_MU_NAME,
                               REGIST_MU_CD,
                               REGIST_MU_ID,
                               REGIST_MU_GENDER,
                               REGIST_MU_PHONE,
                               REGIST_FEE_TYPE,
                               REGIST_MU_SCHOOL,
                               REGIST_MU_GRADE,
                               REGIST_EXAM,
                               REGIST_EXAM_DES,
                               REGIST_PHONE_TYPE,
                               REGIST_PARENT_PHONE,
                               REGIST_TEST_FIRST,
                               REGIST_TEST_SECOND,
                               REGIST_START_DATE,
                               REGIST_END_DATE,
                               REGIST_CHANNEL,
                               REGIST_ROOM,
                               REGIST_SEAT,
                               REGIST_MU_TYPE,
                               REGIST_TYPE,
                               REG_ID,
                               REG_DATE,
                               PAY_CODE)
                               values (
                               		REGIST_FIRST_DATE,
                                       $REGIST_MU_NAME,
                                       $REGIST_MU_CD,
                                       $REGIST_MU_ID,
                                       $REGIST_MU_GENDER,
                                       $REGIST_MU_PHONE,
                                       $REGIST_FEE_TYPE,
                                       $REGIST_MU_SCHOOL,
                                       $REGIST_MU_GRADE,
                                       $REGIST_EXAM,
                                       $REGIST_EXAM_DES,
                                       $REGIST_PHONE_TYPE,
                                       $REGIST_PARENT_PHONE,
                                       $REGIST_TEST_FIRST,
                                       $REGIST_TEST_SECOND,
                                       $REGIST_START_DATE,
                                       $REGIST_END_DATE,
                                       $REGIST_CHANNEL,
                                       $REGIST_ROOM,
                                       $REGIST_SEAT,
                                       $REGIST_MU_TYPE,
                                       $REGIST_TYPE,
                                       $REG_ID,
                                       NOW(),
                                       $PAY_CODE
                                      );
                                     
         update tb_member_user 
        set MU_REGIST_DATE = REGIST_FIRST_DATE
       where MU_CD = $REGIST_MU_CD;
                                      
	
end;

