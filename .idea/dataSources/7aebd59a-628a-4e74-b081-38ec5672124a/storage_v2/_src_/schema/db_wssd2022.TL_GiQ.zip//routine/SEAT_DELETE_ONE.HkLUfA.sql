create
    definer = usr_wssd2022@`211.193.31.117` procedure SEAT_DELETE_ONE(IN $SEAT_SEQ varchar(50),
                                                                      IN $ROOM_CODE varchar(100), IN $ID varchar(100))
begin 
	
	update TB_SEAT ts set ts.DLT_YN='Y' , ts.DLT_ID = $ID, ts.DLT_DATE = NOW()
	where ts.SEAT_SEQ = $SEAT_SEQ;
	

	update TB_ROOM tr set tr.SEAT_COUNT = SEAT_COUNT - 1 , tr.UPDATE_ID = $ID, tr.UPDATE_DATE = NOW()
	where tr.ROOM_CODE = $ROOM_CODE;

	end;

