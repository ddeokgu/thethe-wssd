create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Menu_Group_U1_Str(IN iManagerSeq int,
                                                                                IN iAuthGroupSeq int,
                                                                                IN iAuthGroupName varchar(100),
                                                                                IN iMenuSeq int)
begin
	
	INSERT INTO MANAGER_MENU_GROUP
		(
			AUTH_GROUP_SEQ,
			MENU_SEQ,
			REGIST_BY,
			REGIST_DATE
		)
		VALUES
		(
			iAuthGroupSeq,
			iMenuSeq,
			iManagerSeq,
			now()
		);
END;

