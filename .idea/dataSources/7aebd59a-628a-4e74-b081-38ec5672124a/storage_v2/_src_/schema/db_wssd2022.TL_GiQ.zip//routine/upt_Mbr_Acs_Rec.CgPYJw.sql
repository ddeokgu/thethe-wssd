create
    definer = usr_wssd2022@`211.193.31.117` procedure upt_Mbr_Acs_Rec(IN mbCd varchar(30))
begin
	
	 UPDATE
	         TB_MEMBER_USER
	    SET
	         MU_LOGIN_CNT = MU_LOGIN_CNT + 1
	       , LAST_LOGIN_DATE = now() 
	    WHERE
	          MU_IS_LIVE = 1    
	    AND  
	          MU_CD = mbCd;
	          
	          
	    UPDATE
	         manager_list
	    SET
	         login_date = now() 
	    WHERE
	          MB_CD = mbCd;    
	
	
	
	
	
	
END;

