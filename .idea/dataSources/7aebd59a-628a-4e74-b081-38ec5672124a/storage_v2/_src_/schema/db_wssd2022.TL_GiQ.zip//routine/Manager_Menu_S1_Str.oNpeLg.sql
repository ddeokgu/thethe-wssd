create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_Menu_S1_Str(IN iAuthGroupSeq int,
                                                                          IN iAuthGroupName varchar(100),
                                                                          IN iUseYn char, IN iMenuLevel varchar(10),
                                                                          IN iMenuSeq varchar(10))
BEGIN
  DROP TEMPORARY TABLE IF EXISTS tree_menu;
  DROP TEMPORARY TABLE IF EXISTS tree_menu2;
  DROP TEMPORARY TABLE IF EXISTS tree_menu3;
 
 
  CREATE TEMPORARY TABLE tree_menu (
    select
			1 AS menu_level,
			menu_seq,
			set_icon,
			parent_menu_seq,
			menu_name,
			program_url,
			program_parameter,
			display_yn,
			display_order,
			convert(menu_seq, char(255)) sort
		from manager_menu
		where parent_menu_seq = 0
    );
   
   
    CREATE TEMPORARY TABLE tree_menu2 (	
    select
			menu_level+1 AS menu_level,
			a.menu_seq as menu_seq,
			a.set_icon as set_icon,
			a.parent_menu_seq as parent_menu_seq,
			a.menu_name as menu_name,
			a.program_url as program_url,
			a.program_parameter as program_parameter,
			a.display_yn as display_yn,
			a.display_order as display_order,
			convert(concat(convert(b.sort, char),'>',convert(a.menu_seq, char(255))), char(255)) AS sort
		from manager_menu a
		inner join tree_menu b ON a.parent_menu_seq = b.menu_seq
	);
		
	CREATE TEMPORARY TABLE  tree_menu3 (
    select
			menu_level+1 AS menu_level,
			a.menu_seq as menu_seq,
			a.set_icon as set_icon,
			a.parent_menu_seq as parent_menu_seq,
			a.menu_name as menu_name,
			a.program_url as program_url,
			a.program_parameter as program_parameter,
			a.display_yn as display_yn,
			a.display_order as display_order,
			convert(concat(convert(b.sort, char),'>',convert(a.menu_seq, char(255))), char(255)) AS sort
		from manager_menu a
		inner join tree_menu2 b ON a.parent_menu_seq = b.menu_seq
	);




	select 
		@ROWNUM := @ROWNUM+1 AS rowIndex,
		ANY_VALUE(menu_level) AS menuLevel,
		ANY_VALUE(menu_seq) AS menuSeq,
		ANY_VALUE(set_icon) as setIcon,
		ANY_VALUE(parent_menu_seq) AS parentMenuSeq,
		ANY_VALUE(menu_name) AS menuName,
		ANY_VALUE(program_url) AS programUrl,
		ANY_VALUE(program_parameter) AS programParameter,
		ANY_VALUE(display_yn) AS displayYn,
		ANY_VALUE(display_order) AS displayOrder, 
		ANY_VALUE(display_order) AS newDisplayOrder
	from 
	(   select * from tree_menu
		union all
		select * from tree_menu2
		union all
		select * from tree_menu3
		
	) as T  , (select @ROWNUM:=0) C
	WHERE (iMenuLevel IS NULL OR iMenuLevel = '' OR T.menu_level = iMenuLevel)
	AND (iMenuSeq IS NULL OR iMenuSeq = '' OR T.parent_menu_seq = iMenuSeq)
	order by display_order*1, menu_seq*1, rowIndex desc;
  
	
END;

