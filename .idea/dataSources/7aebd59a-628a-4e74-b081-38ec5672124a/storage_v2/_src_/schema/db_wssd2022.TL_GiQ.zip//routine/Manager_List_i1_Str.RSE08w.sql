create
    definer = usr_wssd2022@`211.193.31.117` procedure Manager_List_i1_Str(IN p_iManagerId varchar(10),
                                                                          IN p_iPassword varchar(200),
                                                                          IN p_iAuthGroupSeq int,
                                                                          IN p_iManagerName varchar(50),
                                                                          IN p_iManagerEmail varchar(50),
                                                                          IN p_iUseYn tinyint,
                                                                          IN p_iDescription varchar(200),
                                                                          IN p_iRegistBy varchar(20),
                                                                          IN p_iUpdateBy varchar(20))
BEGIN

DECLARE v_mb_key INT;
DECLARE v_mb_ct INT;
DECLARE v_mb_code VARCHAR(10);
	   
SET v_mb_ct = (select ifnull(max(MU_SEQ), 0) from tb_member_user);
SET v_mb_key = v_mb_ct + 1;
SET v_mb_code = (SELECT db_wssd2022.ttcc_get_common_code_maker('MUSR', v_mb_key));


-- SQLINES DEMO *** _i1_Str
	  INSERT INTO tb_member_user(
		MU_SEQ,
        MU_ID,
        MU_CD,
        MU_NAME, 
        MB_TYPE,
        MU_PW,
        MU_EMAIL,
        MU_IS_LIVE,
        MU_IS_SLEEP,
        MU_LOGIN_CNT,
        MU_IS_PERMIT,
        MU_PERMIT_CD,
        MU_DATE_PERMIT,
        MU_UPD_CD,
        MU_UPD_DATE,
        REG_DATE,
        DLT_YN
    ) VALUES (
		v_mb_key,
        p_iManagerId,
        v_mb_code,
        p_iManagerName, 
        'M',
        p_iPassword,
        p_iManagerEmail,
        p_iUseYn,
        0,
        0,
        'Y',
        p_iRegistBy,
        NOW(),
        p_iUpdateBy,
        NOW(),
        NOW(),
        'N'
    );
	
	INSERT INTO MANAGER_LIST(
        MANAGER_ID,
        PASSWORD,
        LOGIN_FAIL_COUNT,
        AUTH_GROUP_SEQ,
        MANAGER_NAME,
        MANAGER_EMAIL,
        USE_YN,
        DESCRIPTION,
        REGIST_BY,
        REGIST_DATE,
        UPDATE_BY,
        UPDATE_DATE,
        MB_CD
    ) VALUES (
        p_iManagerId,
        p_iPassword,
        0,
        p_iAuthGroupSeq,
        p_iManagerName,
        p_iManagerEmail,
        p_iUseYn,
        p_iDescription,
        p_iRegistBy,
        NOW(),
        p_iUpdateBy,
        NOW(),
        v_mb_code
    );
   
   
   
   
   /*INSERT INTO manager_menu_group (
        auth_group_seq,
        menu_seq,
        regist_by,
        regist_date
    ) VALUES (
       p_iAuthGroupSeq,
       17,
       p_iRegistBy,
        NOW()
    );*/

END;

